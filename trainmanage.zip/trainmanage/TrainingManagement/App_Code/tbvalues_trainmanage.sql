﻿use trainmanage
go
--1
SET Identity_Insert tblTinChi OFF
DBCC CHECKIDENT (tblTinChi, RESEED, 0);
insert into tblTinChi values('TC1','1')
insert into tblTinChi values('TC2','2')
insert into tblTinChi values('TC3','3')
insert into tblTinChi values('TC4','4')
insert into tblTinChi values('TC5','5')
insert into tblTinChi values('TC6','6')
--2
/*
insert into tblChucVu values('CV1',N'Trường Khoa')
insert into tblChucVu values('CV2',N'Phó Khoa')
insert into tblChucVu values('CV3',N'Giảng Viên')
insert into tblChucVu values('CV4',N'Bảo Vệ')
insert into tblChucVu values('CV5',N'Nhân Viên')
*/
--3
SET Identity_Insert tblHocKy OFF
DBCC CHECKIDENT (tblHocKy, RESEED, 0);
insert into tblHocKy values('HK1',N'Học kỳ 1')
insert into tblHocKy values('HK2',N'Học kỳ 2')
insert into tblHocKy values('HK3',N'Học kỳ 3')
insert into tblHocKy values('HK4',N'Học kỳ 4')
insert into tblHocKy values('HK5',N'Học kỳ 5')
insert into tblHocKy values('HK6',N'Học kỳ 6')
insert into tblHocKy values('HK7',N'Học kỳ 7')
insert into tblHocKy values('HK8',N'Học kỳ 8')
--4
SET Identity_Insert tblKhoa OFF
DBCC CHECKIDENT (tblKhoa, RESEED, 0);
insert into tblKhoa values('K01',N'Công nghệ thông tin và truyền thông','0292113114')
insert into tblKhoa values('K02',N'Đại cương','0292113113')
insert into tblKhoa values('K03',N'Tự nhiên','0292113112')
insert into tblKhoa values('K04',N'Công nghệ','0292113111')
insert into tblKhoa values('K05',N'Môi trường','0292113115')
insert into tblKhoa values('K06',N'Kinh tế','0292113116')
insert into tblKhoa values('K07',N'Luật','0292113117')
insert into tblKhoa values('K08',N'Nông nghiệp','0292113118')
insert into tblKhoa values('K09',N'Khoa học','0292113119')
--5
SET Identity_Insert tblTrangThai OFF
DBCC CHECKIDENT (tblTrangThai, RESEED, 0);
insert into tblTrangThai values('TT1',N'Có ý thích')
insert into tblTrangThai values('TT2',N'Đăng ký')
insert into tblTrangThai values('TT3',N'Tạm hoãn')
insert into tblTrangThai values('TT4',N'Chưa ghi danh')
--6
SET Identity_Insert tblNienKhoa OFF
DBCC CHECKIDENT (tblNienKhoa, RESEED, 0);
insert into tblNienKhoa values('NK1',N'K38','2012','2015')
insert into tblNienKhoa values('NK2',N'K39','2013','2016')
insert into tblNienKhoa values('NK3',N'K40','2014','2017')
insert into tblNienKhoa values('NK4',N'K41','2015','2018')
insert into tblNienKhoa values('NK5',N'K42','2016','2019')
insert into tblNienKhoa values('NK6',N'K43','2017','2020')
insert into tblNienKhoa values('NK7',N'K44','2018','2021')
--7
SET Identity_Insert tblChuongTrinhDaoTao OFF
DBCC CHECKIDENT (tblChuongTrinhDaoTao, RESEED, 0);
insert into tblChuongTrinhDaoTao values('CT1','23')
insert into tblChuongTrinhDaoTao values('CT2','24')
insert into tblChuongTrinhDaoTao values('CT3','25')
insert into tblChuongTrinhDaoTao values('CT4','26')
insert into tblChuongTrinhDaoTao values('CT5','27')
insert into tblChuongTrinhDaoTao values('CT6','28')
insert into tblChuongTrinhDaoTao values('CT7','29')
insert into tblChuongTrinhDaoTao values('CT8','30')
--8
SET Identity_Insert tblLop OFF
DBCC CHECKIDENT (tblLop, RESEED, 0);
insert into tblLop values('1','1','L01',N'Liên thông 1','25')
insert into tblLop values('1','1','L02',N'Liên thông 2','24')
insert into tblLop values('1','2','L03',N'Liên thông 3','26')
insert into tblLop values('1','2','L04',N'Liên thông 4','26')
insert into tblLop values('1','3','L05',N'Liên thông 5','27')
insert into tblLop values('1','3','L06',N'Liên thông 6','27')
insert into tblLop values('1','4','L07',N'Liên thông 7','28')
insert into tblLop values('1','5','L08',N'Liên thông 8','29')
insert into tblLop values('1','6','L09',N'Liên thông 9','29')
--9
SET Identity_Insert tblMonHoc OFF
DBCC CHECKIDENT (tblMonHoc, RESEED, 0);
insert into tblMonHoc values('1','1','3','MH1',N'Lập trình ứng dụng Java')
insert into tblMonHoc values('1','1','3','MH2',N'Lập trình ứng dụng Windows')
insert into tblMonHoc values('2','2','3','MH3',N'Lập trình ứng dụng Android')
insert into tblMonHoc values('6','2','3','MH4',N'Lập trình ứng dụng macOS')
insert into tblMonHoc values('7','3','3','MH5',N'Lập trình mạng')
insert into tblMonHoc values('2','3','3','MH6',N'Lập trình web')
insert into tblMonHoc values('4','4','3','MH7',N'Hệ quản trị cơ sở dữ liệu')
insert into tblMonHoc values('3','5','3','MH8',N'Quản trị mạng')
insert into tblMonHoc values('5','6','3','MH9',N'Phân tích hệ thống thông tin')
--10
/*
insert into tblGiaoVien values('3','1','1','GV1',N'Nguyễn Văn A','1980',N'Nam',N'Cần Thơ',N'Cần Thơ')
insert into tblGiaoVien values('3','1','2','GV2',N'Trần Thị B','1979',N'Nữ',N'An Giang',N'Cần Thơ')
insert into tblGiaoVien values('3','1','3','GV3',N'Võ Văn C','1981',N'Nam',N'Kiên Giang',N'Cần Thơ')
insert into tblGiaoVien values('3','1','4','GV4',N'Hứa Vỹ D','1977',N'Nam',N'Tiền Giang',N'Cần Thơ')
insert into tblGiaoVien values('3','1','5','GV5',N'Đỗ Huy E','1982',N'Nam',N'Hậu Giang',N'Cần Thơ')
insert into tblGiaoVien values('3','1','6','GV6',N'Trịnh Xuân F','1983',N'Nữ',N'Bạc Liêu',N'Cần Thơ')
insert into tblGiaoVien values('3','1','3','GV7',N'Cao Kim G','1984',N'Nữ',N'Cà Mau',N'Cần Thơ')
insert into tblGiaoVien values('3','1','2','GV8',N'Tô Thanh H','1985',N'Nam',N'Đồng Tháp',N'Cần Thơ')
insert into tblGiaoVien values('3','1','6','GV9',N'Định Diệp I','1986',N'Nữ',N'Vĩnh Long',N'Cần Thơ')
*/
--11
SET Identity_Insert tblSinhvien OFF
DBCC CHECKIDENT (tblSinhVien, RESEED, 0);
insert into tblSinhVien values('1','2','SV1',N'Phạm Thị J','1992',N'Nữ',N'Cần Thơ',N'Cần Thơ')
insert into tblSinhVien values('1','2','SV2',N'Lê Văn L','1993',N'Nam',N'Bạc Liêu',N'Bạc Liêu')
insert into tblSinhVien values('2','2','SV3',N'Huỳnh Tấn O','1991',N'Nam',N'Hậu Giang',N'Hậu Giang')
insert into tblSinhVien values('3','2','SV4',N'Vũ Lại Y','1993',N'Nữ',N'Kiên Giang',N'Kiên Giang')
insert into tblSinhVien values('7','2','SV5',N'Dương Chí Q','1994',N'Nam',N'Tiền Giang',N'Tiền Giang')
insert into tblSinhVien values('8','2','SV6',N'Lý Chí X','1995',N'Nam',N'An Giang',N'An Giang')
insert into tblSinhVien values('4','2','SV7',N'Ngô Tùng M','1995',N'Nam',N'Cà Mau',N'Cà Mau')
insert into tblSinhVien values('5','2','SV8',N'Hồ Quý S','1990',N'Nữ',N'Vĩnh Long',N'Vĩnh Long')
insert into tblSinhVien values('2','2','SV9',N'Đặng Bá N','1990',N'Nam',N'Cần Thơ',N'Cần Thơ')
insert into tblSinhVien values('6','2','SV10',N'Hoàng Kim P','1990',N'Nữ',N'Đồng Tháp',N'Đồng Tháp')
--select * from tblSinhVien
--GO
--12
SET Identity_Insert tblKetQua OFF
DBCC CHECKIDENT (tblKetQua, RESEED, 0);
insert into tblKetQua values('0','6','10','3','7','1.5',N'Khá','')
insert into tblKetQua values('1','1','7.2','7','0','2.9',N'Tốt','')
insert into tblKetQua values('2','2','8.3','8','0','3.0',N'Tốt','')
insert into tblKetQua values('3','3','7.5','9','0','2.5',N'Tốt','')
insert into tblKetQua values('4','4','7.7','10','0','3.1',N'Tốt','')
insert into tblKetQua values('5','5','6.9','6','0','2.8',N'Tốt','')
insert into tblKetQua values('6','6','5.3','7','0','2.7',N'Tốt','')
insert into tblKetQua values('7','8','5.6','5','0','2.0',N'Khá','')
insert into tblKetQua values('8','8','8.9','6','0','2.6',N'Tốt','')
insert into tblKetQua values('9','7','9.2','3','8','1.8',N'Khá','')
--13
SET Identity_Insert tblTaiKhoan OFF
DBCC CHECKIDENT (tblTaiKhoan, RESEED, 0);
insert into tblTaiKhoan values('qt',N'12345678',N'Quản trị viên')
insert into tblTaiKhoan values('ql',N'12345678',N'Quản lý chương trình đào tạo viên')
insert into tblTaiKhoan values('gv1',N'12345678',N'Giáo viên')
insert into tblTaiKhoan values('gv2',N'12345678',N'Giáo viên')
insert into tblTaiKhoan values('gv3',N'12345678',N'Giáo viên')
insert into tblTaiKhoan values('gv4',N'12345678',N'Giáo viên')
insert into tblTaiKhoan values('gv5',N'12345678',N'Giáo viên')
insert into tblTaiKhoan values('gv6',N'12345678',N'Giáo viên')
insert into tblTaiKhoan values('gv7',N'12345678',N'Giáo viên')
insert into tblTaiKhoan values('gv8',N'12345678',N'Giáo viên')
--14
SET Identity_Insert tblThongTin OFF
DBCC CHECKIDENT (tblThongTin, RESEED, 0);
insert into tblThongTin values('0',N'Hùng',N'Quản trị viên','1993',N'Nữ',N'Tiền Giang')
insert into tblThongTin values('1',N'Phát',N'Quản lý chương trình đào tạo viên','1994',N'Nam',N'Cần Thơ')
insert into tblThongTin values('2',N'Giang',N'Giáo viên','1985',N'Nam',N'Bến Tre')
insert into tblThongTin values('3',N'Hiếu',N'Giáo viên','1994',N'Nam',N'Cà Mau')
insert into tblThongTin values('4',N'Khoa',N'Giáo viên','1994',N'Nam',N'An Giang')
insert into tblThongTin values('5',N'Tâm',N'Giáo viên','1983',N'Nam',N'Kiên Giang')
insert into tblThongTin values('6',N'Thiên',N'Giáo viên','1993',N'Nam',N'Hậu Giang')
insert into tblThongTin values('7',N'Khánh',N'Giáo viên','1990',N'Nữ',N'Vĩnh Long')
insert into tblThongTin values('8',N'Cường',N'Giáo viên','1991',N'Nam',N'Bạc Liêu')
insert into tblThongTin values('9',N'Hưng',N'Giáo viên','1992',N'Nam',N'Sóc Trăng')


