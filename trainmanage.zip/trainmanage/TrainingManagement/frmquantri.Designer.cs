﻿namespace TrainingManagement
{
    partial class frmQuanTri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuanTri));
            this.mstquantri = new System.Windows.Forms.MenuStrip();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinCáNhânToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.niênKhóaToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.họcKỳToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.khoaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lớpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mônHọcToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.niênKhóaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sinhViênToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tínChỉToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pnQuanTri = new System.Windows.Forms.Panel();
            this.mstquantri.SuspendLayout();
            this.SuspendLayout();
            // 
            // mstquantri
            // 
            this.mstquantri.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.thoátToolStripMenuItem});
            this.mstquantri.Location = new System.Drawing.Point(0, 0);
            this.mstquantri.Name = "mstquantri";
            this.mstquantri.Size = new System.Drawing.Size(770, 24);
            this.mstquantri.TabIndex = 9;
            this.mstquantri.Text = "mstquantri";
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinCáNhânToolStripMenuItem,
            this.thoátToolStripMenuItem1});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.quảnLýToolStripMenuItem.Text = "Tài khoản";
            // 
            // thôngTinCáNhânToolStripMenuItem
            // 
            this.thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
            this.thôngTinCáNhânToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.thôngTinCáNhânToolStripMenuItem.Text = "Thông tin cá nhân";
            this.thôngTinCáNhânToolStripMenuItem.Click += new System.EventHandler(this.thôngTinCáNhânToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem1
            // 
            this.thoátToolStripMenuItem1.Name = "thoátToolStripMenuItem1";
            this.thoátToolStripMenuItem1.Size = new System.Drawing.Size(171, 22);
            this.thoátToolStripMenuItem1.Text = "Thoát";
            this.thoátToolStripMenuItem1.Click += new System.EventHandler(this.thoátToolStripMenuItem1_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.niênKhóaToolStripMenuItem1,
            this.họcKỳToolStripMenuItem,
            this.khoaToolStripMenuItem,
            this.lớpToolStripMenuItem,
            this.mônHọcToolStripMenuItem,
            this.mônHọcToolStripMenuItem1,
            this.niênKhóaToolStripMenuItem,
            this.sinhViênToolStripMenuItem1,
            this.tínChỉToolStripMenuItem});
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.thoátToolStripMenuItem.Text = "Quản lý";
            // 
            // niênKhóaToolStripMenuItem1
            // 
            this.niênKhóaToolStripMenuItem1.Name = "niênKhóaToolStripMenuItem1";
            this.niênKhóaToolStripMenuItem1.Size = new System.Drawing.Size(195, 22);
            this.niênKhóaToolStripMenuItem1.Text = "Chương Trình Đào Tạo";
            // 
            // họcKỳToolStripMenuItem
            // 
            this.họcKỳToolStripMenuItem.Name = "họcKỳToolStripMenuItem";
            this.họcKỳToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.họcKỳToolStripMenuItem.Text = "Học Kỳ";
            // 
            // khoaToolStripMenuItem
            // 
            this.khoaToolStripMenuItem.Name = "khoaToolStripMenuItem";
            this.khoaToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.khoaToolStripMenuItem.Text = "Khoa";
            this.khoaToolStripMenuItem.Click += new System.EventHandler(this.khoaToolStripMenuItem_Click);
            // 
            // lớpToolStripMenuItem
            // 
            this.lớpToolStripMenuItem.Name = "lớpToolStripMenuItem";
            this.lớpToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.lớpToolStripMenuItem.Text = "Lớp";
            this.lớpToolStripMenuItem.Click += new System.EventHandler(this.lớpToolStripMenuItem_Click);
            // 
            // mônHọcToolStripMenuItem
            // 
            this.mônHọcToolStripMenuItem.Name = "mônHọcToolStripMenuItem";
            this.mônHọcToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.mônHọcToolStripMenuItem.Text = "Môn Học";
            // 
            // mônHọcToolStripMenuItem1
            // 
            this.mônHọcToolStripMenuItem1.Name = "mônHọcToolStripMenuItem1";
            this.mônHọcToolStripMenuItem1.Size = new System.Drawing.Size(195, 22);
            this.mônHọcToolStripMenuItem1.Text = "Người dùng";
            this.mônHọcToolStripMenuItem1.Click += new System.EventHandler(this.mônHọcToolStripMenuItem1_Click);
            // 
            // niênKhóaToolStripMenuItem
            // 
            this.niênKhóaToolStripMenuItem.Name = "niênKhóaToolStripMenuItem";
            this.niênKhóaToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.niênKhóaToolStripMenuItem.Text = "Niên Khóa";
            // 
            // sinhViênToolStripMenuItem1
            // 
            this.sinhViênToolStripMenuItem1.Name = "sinhViênToolStripMenuItem1";
            this.sinhViênToolStripMenuItem1.Size = new System.Drawing.Size(195, 22);
            this.sinhViênToolStripMenuItem1.Text = "Sinh Viên";
            // 
            // tínChỉToolStripMenuItem
            // 
            this.tínChỉToolStripMenuItem.Name = "tínChỉToolStripMenuItem";
            this.tínChỉToolStripMenuItem.Size = new System.Drawing.Size(195, 22);
            this.tínChỉToolStripMenuItem.Text = "Tín Chỉ";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(0, 606);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(770, 51);
            this.textBox1.TabIndex = 14;
            this.textBox1.Text = "TRƯỜNG ĐẠI HỌC CẦN THƠ\r\nKHOA CÔNG NGHỆ THÔNG TIN VÀ TRUYỀN THÔNG\r\nLỚP LIÊN THÔNG " +
    "DC15V7K2\r\nNhóm 5 © 2017";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnQuanTri
            // 
            this.pnQuanTri.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnQuanTri.Location = new System.Drawing.Point(0, 24);
            this.pnQuanTri.Name = "pnQuanTri";
            this.pnQuanTri.Size = new System.Drawing.Size(770, 480);
            this.pnQuanTri.TabIndex = 17;
            this.pnQuanTri.Paint += new System.Windows.Forms.PaintEventHandler(this.pnQuanTri_Paint);
            // 
            // frmQuanTri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(770, 657);
            this.Controls.Add(this.pnQuanTri);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.mstquantri);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmQuanTri";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PHẦN QUẢN LÝ DÀNH CHO QUẢN TRỊ VIÊN";
            this.mstquantri.ResumeLayout(false);
            this.mstquantri.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mstquantri;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mônHọcToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem lớpToolStripMenuItem;
        private System.Windows.Forms.Panel pnQuanTri;
        private System.Windows.Forms.ToolStripMenuItem niênKhóaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem khoaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem niênKhóaToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem mônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sinhViênToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem họcKỳToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tínChỉToolStripMenuItem;
    }
}