﻿namespace TrainingManagement
{
    partial class frmTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.danhSáchSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chiTiếtMônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lậpBáoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchCácMônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mônHọcToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinCáNhânToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label2 = new System.Windows.Forms.Label();
            this.mstgiaovien = new System.Windows.Forms.MenuStrip();
            this.pnQLThongTinGiaoVien = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.mstgiaovien.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::TrainingManagement.Properties.Resources.logo_ctu;
            this.pictureBox1.Location = new System.Drawing.Point(725, 25);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(46, 39);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 15;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(-4, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(621, 37);
            this.label1.TabIndex = 13;
            this.label1.Text = "PHẦN MỀM QUẢN LÝ CHƯƠNG TRÌNH ĐÀO TẠO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // danhSáchSinhViênToolStripMenuItem
            // 
            this.danhSáchSinhViênToolStripMenuItem.Name = "danhSáchSinhViênToolStripMenuItem";
            this.danhSáchSinhViênToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.danhSáchSinhViênToolStripMenuItem.Text = "Danh sách sinh viên";
            // 
            // chiTiếtMônHọcToolStripMenuItem
            // 
            this.chiTiếtMônHọcToolStripMenuItem.Name = "chiTiếtMônHọcToolStripMenuItem";
            this.chiTiếtMônHọcToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.chiTiếtMônHọcToolStripMenuItem.Text = "Chi tiết môn học";
            // 
            // lậpBáoCáoToolStripMenuItem
            // 
            this.lậpBáoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chiTiếtMônHọcToolStripMenuItem,
            this.danhSáchSinhViênToolStripMenuItem});
            this.lậpBáoCáoToolStripMenuItem.Name = "lậpBáoCáoToolStripMenuItem";
            this.lậpBáoCáoToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.lậpBáoCáoToolStripMenuItem.Text = "Lập báo cáo";
            // 
            // kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem
            // 
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Name = "kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem";
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Text = "Kết quả các môn học của Sinh viên";
            // 
            // danhSáchCácMônHọcToolStripMenuItem
            // 
            this.danhSáchCácMônHọcToolStripMenuItem.Name = "danhSáchCácMônHọcToolStripMenuItem";
            this.danhSáchCácMônHọcToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.danhSáchCácMônHọcToolStripMenuItem.Text = "Danh sách các môn học";
            // 
            // danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem
            // 
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Name = "danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem";
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Text = "Danh sách các chương trình đào tạo";
            // 
            // tìmKiếmToolStripMenuItem
            // 
            this.tìmKiếmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem,
            this.danhSáchCácMônHọcToolStripMenuItem,
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem});
            this.tìmKiếmToolStripMenuItem.Name = "tìmKiếmToolStripMenuItem";
            this.tìmKiếmToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.tìmKiếmToolStripMenuItem.Text = "Tìm kiếm";
            // 
            // mônHọcToolStripMenuItem1
            // 
            this.mônHọcToolStripMenuItem1.Name = "mônHọcToolStripMenuItem1";
            this.mônHọcToolStripMenuItem1.Size = new System.Drawing.Size(122, 22);
            this.mônHọcToolStripMenuItem1.Text = "Môn học";
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mônHọcToolStripMenuItem1});
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.thoátToolStripMenuItem.Text = "Quản lý";
            // 
            // mônHọcToolStripMenuItem
            // 
            this.mônHọcToolStripMenuItem.Name = "mônHọcToolStripMenuItem";
            this.mônHọcToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.mônHọcToolStripMenuItem.Text = "Thoát";
            this.mônHọcToolStripMenuItem.Click += new System.EventHandler(this.mônHọcToolStripMenuItem_Click);
            // 
            // thôngTinCáNhânToolStripMenuItem
            // 
            this.thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
            this.thôngTinCáNhânToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.thôngTinCáNhânToolStripMenuItem.Text = "Thông tin cá nhân";
            this.thôngTinCáNhânToolStripMenuItem.Click += new System.EventHandler(this.thôngTinCáNhânToolStripMenuItem_Click);
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinCáNhânToolStripMenuItem,
            this.mônHọcToolStripMenuItem});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.quảnLýToolStripMenuItem.Text = "Tài khoản";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label2.Location = new System.Drawing.Point(127, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(501, 37);
            this.label2.TabIndex = 14;
            this.label2.Text = "PHẦN QUẢN LÝ DÀNH CHO GIÁO VIÊN";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mstgiaovien
            // 
            this.mstgiaovien.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.thoátToolStripMenuItem,
            this.tìmKiếmToolStripMenuItem,
            this.lậpBáoCáoToolStripMenuItem});
            this.mstgiaovien.Location = new System.Drawing.Point(0, 0);
            this.mstgiaovien.Name = "mstgiaovien";
            this.mstgiaovien.Size = new System.Drawing.Size(770, 24);
            this.mstgiaovien.TabIndex = 12;
            this.mstgiaovien.Text = "mstgiaovien";
            // 
            // pnQLThongTinGiaoVien
            // 
            this.pnQLThongTinGiaoVien.Location = new System.Drawing.Point(-1, 109);
            this.pnQLThongTinGiaoVien.Name = "pnQLThongTinGiaoVien";
            this.pnQLThongTinGiaoVien.Size = new System.Drawing.Size(772, 480);
            this.pnQLThongTinGiaoVien.TabIndex = 16;
            this.pnQLThongTinGiaoVien.Paint += new System.Windows.Forms.PaintEventHandler(this.pnQLThongTinGiaoVien_Paint);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(0, 606);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(770, 51);
            this.textBox1.TabIndex = 17;
            this.textBox1.Text = "TRƯỜNG ĐẠI HỌC CẦN THƠ\r\nKHOA CÔNG NGHỆ THÔNG TIN VÀ TRUYỀN THÔNG\r\nLỚP LIÊN THÔNG " +
    "DC15V7K2\r\nNhóm 5 © 2017";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // frmTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(770, 657);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pnQLThongTinGiaoVien);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.mstgiaovien);
            this.Name = "frmTest";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Test";
            this.Load += new System.EventHandler(this.frmTest_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.mstgiaovien.ResumeLayout(false);
            this.mstgiaovien.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem danhSáchSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chiTiếtMônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lậpBáoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchCácMônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mônHọcToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip mstgiaovien;
        private System.Windows.Forms.Panel pnQLThongTinGiaoVien;
        private System.Windows.Forms.TextBox textBox1;
    }
}