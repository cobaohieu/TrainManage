﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

namespace TrainingManagement.GUI
{
    public partial class tblLop : UserControl
    {
        BLL.LopBLL bllLop;
        public tblLop()
        {
            InitializeComponent();
            bllLop = new BLL.LopBLL();
        }

        private void tblLop_Load(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt = bllLop.getAllLop();
            dgvLop.DataSource = dt;
        }

    }
}
