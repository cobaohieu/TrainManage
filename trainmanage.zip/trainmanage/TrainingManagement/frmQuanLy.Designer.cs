﻿namespace TrainingManagement
{
    partial class frmQuanLy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmQuanLy));
            this.mstquanly = new System.Windows.Forms.MenuStrip();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinCáNhânToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chươngTrìnhĐàoTạoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mônHọcToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.trạngTháiCủaSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchCácMônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lậpBáoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chiTiếtMônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.mstquanly.SuspendLayout();
            this.SuspendLayout();
            // 
            // mstquanly
            // 
            this.mstquanly.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.thoátToolStripMenuItem,
            this.tìmKiếmToolStripMenuItem,
            this.lậpBáoCáoToolStripMenuItem});
            this.mstquanly.Location = new System.Drawing.Point(0, 0);
            this.mstquanly.Name = "mstquanly";
            this.mstquanly.Size = new System.Drawing.Size(770, 24);
            this.mstquanly.TabIndex = 8;
            this.mstquanly.Text = "mstquanly";
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinCáNhânToolStripMenuItem,
            this.thoátToolStripMenuItem1});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.quảnLýToolStripMenuItem.Text = "Tài khoản";
            // 
            // thôngTinCáNhânToolStripMenuItem
            // 
            this.thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
            this.thôngTinCáNhânToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.thôngTinCáNhânToolStripMenuItem.Text = "Thông tin cá nhân";
            this.thôngTinCáNhânToolStripMenuItem.Click += new System.EventHandler(this.thôngTinCáNhânToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem1
            // 
            this.thoátToolStripMenuItem1.Name = "thoátToolStripMenuItem1";
            this.thoátToolStripMenuItem1.Size = new System.Drawing.Size(171, 22);
            this.thoátToolStripMenuItem1.Text = "Thoát";
            this.thoátToolStripMenuItem1.Click += new System.EventHandler(this.thoátToolStripMenuItem1_Click_1);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chươngTrìnhĐàoTạoToolStripMenuItem,
            this.mônHọcToolStripMenuItem2,
            this.trạngTháiCủaSinhViênToolStripMenuItem});
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.thoátToolStripMenuItem.Text = "Quản lý";
            // 
            // chươngTrìnhĐàoTạoToolStripMenuItem
            // 
            this.chươngTrìnhĐàoTạoToolStripMenuItem.Name = "chươngTrìnhĐàoTạoToolStripMenuItem";
            this.chươngTrìnhĐàoTạoToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.chươngTrìnhĐàoTạoToolStripMenuItem.Text = "Chương trình đào tạo";
            this.chươngTrìnhĐàoTạoToolStripMenuItem.Click += new System.EventHandler(this.chươngTrìnhĐàoTạoToolStripMenuItem_Click);
            // 
            // mônHọcToolStripMenuItem2
            // 
            this.mônHọcToolStripMenuItem2.Name = "mônHọcToolStripMenuItem2";
            this.mônHọcToolStripMenuItem2.Size = new System.Drawing.Size(201, 22);
            this.mônHọcToolStripMenuItem2.Text = "Môn học";
            this.mônHọcToolStripMenuItem2.Click += new System.EventHandler(this.mônHọcToolStripMenuItem2_Click);
            // 
            // trạngTháiCủaSinhViênToolStripMenuItem
            // 
            this.trạngTháiCủaSinhViênToolStripMenuItem.Name = "trạngTháiCủaSinhViênToolStripMenuItem";
            this.trạngTháiCủaSinhViênToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.trạngTháiCủaSinhViênToolStripMenuItem.Text = "Trạng thái của Sinh viên";
            this.trạngTháiCủaSinhViênToolStripMenuItem.Click += new System.EventHandler(this.trạngTháiCủaSinhViênToolStripMenuItem_Click);
            // 
            // tìmKiếmToolStripMenuItem
            // 
            this.tìmKiếmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem,
            this.danhSáchCácMônHọcToolStripMenuItem,
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem});
            this.tìmKiếmToolStripMenuItem.Name = "tìmKiếmToolStripMenuItem";
            this.tìmKiếmToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.tìmKiếmToolStripMenuItem.Text = "Tìm kiếm";
            // 
            // danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem
            // 
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Name = "danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem";
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Text = "Danh sách các chương trình đào tạo";
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Click += new System.EventHandler(this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem_Click);
            // 
            // danhSáchCácMônHọcToolStripMenuItem
            // 
            this.danhSáchCácMônHọcToolStripMenuItem.Name = "danhSáchCácMônHọcToolStripMenuItem";
            this.danhSáchCácMônHọcToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.danhSáchCácMônHọcToolStripMenuItem.Text = "Danh sách các môn học";
            this.danhSáchCácMônHọcToolStripMenuItem.Click += new System.EventHandler(this.danhSáchCácMônHọcToolStripMenuItem_Click);
            // 
            // kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem
            // 
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Name = "kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem";
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Text = "Kết quả các môn học của Sinh viên";
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Click += new System.EventHandler(this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem_Click);
            // 
            // lậpBáoCáoToolStripMenuItem
            // 
            this.lậpBáoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chiTiếtMônHọcToolStripMenuItem,
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1});
            this.lậpBáoCáoToolStripMenuItem.Name = "lậpBáoCáoToolStripMenuItem";
            this.lậpBáoCáoToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.lậpBáoCáoToolStripMenuItem.Text = "Lập báo cáo";
            // 
            // chiTiếtMônHọcToolStripMenuItem
            // 
            this.chiTiếtMônHọcToolStripMenuItem.Name = "chiTiếtMônHọcToolStripMenuItem";
            this.chiTiếtMônHọcToolStripMenuItem.Size = new System.Drawing.Size(259, 22);
            this.chiTiếtMônHọcToolStripMenuItem.Text = "Bằng tốt nghiệp";
            this.chiTiếtMônHọcToolStripMenuItem.Click += new System.EventHandler(this.chiTiếtMônHọcToolStripMenuItem_Click);
            // 
            // kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1
            // 
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1.Name = "kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1";
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1.Size = new System.Drawing.Size(259, 22);
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1.Text = "Kết quả các môn học của Sinh viên";
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1.Click += new System.EventHandler(this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(0, 606);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(770, 51);
            this.textBox1.TabIndex = 13;
            this.textBox1.Text = "TRƯỜNG ĐẠI HỌC CẦN THƠ\r\nKHOA CÔNG NGHỆ THÔNG TIN VÀ TRUYỀN THÔNG\r\nLỚP LIÊN THÔNG " +
    "DC15V7K2\r\nNhóm 5 © 2017";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // frmQuanLy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(770, 657);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.mstquanly);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmQuanLy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PHẦN QUẢN LÝ DÀNH CHO QUẢN LÝ VIÊN";
            this.mstquanly.ResumeLayout(false);
            this.mstquanly.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void thoátToolStripMenuItem1_Click(object sender, System.EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        #endregion

        private System.Windows.Forms.MenuStrip mstquanly;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lậpBáoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chiTiếtMônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mônHọcToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem trạngTháiCủaSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchCácMônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chươngTrìnhĐàoTạoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem1;
        private System.Windows.Forms.TextBox textBox1;
    }
}