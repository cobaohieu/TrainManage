﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TrainingManagement
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        private string gioithieu;

        private void txtGioiThieu_TextChanged(object sender, EventArgs e)
        {
            txtGioiThieu.Text = gioithieu; 
            gioithieu = "Cổ Bảo Hiếu - 0939922913";

        }
    }
}
