﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingManagement.DAL
{
    class MonHocDAL
    {
        DataServices ds;
        SqlConnection con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;
        public MonHocDAL()
        {
            ds = new DataServices();
        }
        public DataTable getAllMonHoc()
        {
            string sql = "sp_tblMonHoc_SelectAll";
            try
            {
                con = ds.getConnect();
                da = new SqlDataAdapter(sql, con);
                con.Open();
                dt = new DataTable();
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                da.Dispose();
                con.Close();
            }
            return dt;
        }
        public DataTable getAllMonHoc(int id)
        {
            string sql = "sp_tblMonHoc_SelectID";
            try
            {
                con = ds.getConnect();
                da = new SqlDataAdapter(sql, con);
                con.Open();
                dt = new DataTable();
                da.Fill(dt);
            }
            catch (Exception ex)
            {

            }
            finally
            {
                da.Dispose();
                con.Close();
            }
            return dt;
        }
        public bool insertMonHoc(Entities.tblMonHoc mh)
        {
            bool check = false;
            string sql = "sp_tblMonHoc_Insert";
            try
            {
                con = ds.getConnect();
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = sql;
                cmd.Connection = con;
                cmd.Parameters.Add("@idchuongtrinh", SqlDbType.Int).Value = mh.Idchuongtrinh;
                cmd.Parameters.Add("@idhocky", SqlDbType.Int).Value = mh.Idhocky;
                cmd.Parameters.Add("@idtinchi", SqlDbType.Int).Value = mh.Idtinchi;
                cmd.Parameters.Add("@mamonhoc", SqlDbType.NVarChar).Value = mh.Mamonhoc;
                cmd.Parameters.Add("@tenmonhoc", SqlDbType.NVarChar).Value = mh.Tenmonhoc;
                cmd.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return check;
        }
        public bool updateMonHoc(Entities.tblMonHoc mh)
        {
            bool check = false;
            string sql = "sp_tblMonHoc_Update";
            try
            {
                con = ds.getConnect();
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = sql;
                cmd.Connection = con;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = mh.Id;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@idchuongtrinh", SqlDbType.Int).Value = mh.Idchuongtrinh;
                cmd.Parameters.Add("@idhocky", SqlDbType.Int).Value = mh.Idhocky;
                cmd.Parameters.Add("@idtinchi", SqlDbType.Int).Value = mh.Idtinchi;
                cmd.Parameters.Add("@mamonhoc", SqlDbType.NVarChar).Value = mh.Mamonhoc;
                cmd.Parameters.Add("@tenmonhoc", SqlDbType.NVarChar).Value = mh.Tenmonhoc;
                cmd.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return check;
        }
        public bool deleteMonHoc(Entities.tblMonHoc mh)
        {
            bool check = false;
            string sql = "sp_tblMonHoc_Delete";
            try
            {
                con = ds.getConnect();
                cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = mh.Id;
                cmd.ExecuteNonQuery();
                check = true;
            }
            catch (Exception ex)
            {

            }
            finally
            {
                cmd.Dispose();
                con.Close();
            }
            return check;
        }
    }
}
