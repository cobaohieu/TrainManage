﻿namespace TrainingManagement
{
    partial class frmGiaoVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGiaoVien));
            this.mstgiaovien = new System.Windows.Forms.MenuStrip();
            this.quảnLýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thôngTinCáNhânToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.thoátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mônHọcToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tìmKiếmToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchCácMônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lậpBáoCáoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chiTiếtMônHọcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.danhSáchSinhViênToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.mstgiaovien.SuspendLayout();
            this.SuspendLayout();
            // 
            // mstgiaovien
            // 
            this.mstgiaovien.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.quảnLýToolStripMenuItem,
            this.thoátToolStripMenuItem,
            this.tìmKiếmToolStripMenuItem,
            this.lậpBáoCáoToolStripMenuItem});
            this.mstgiaovien.Location = new System.Drawing.Point(0, 0);
            this.mstgiaovien.Name = "mstgiaovien";
            this.mstgiaovien.Size = new System.Drawing.Size(770, 24);
            this.mstgiaovien.TabIndex = 7;
            this.mstgiaovien.Text = "mstgiaovien";
            // 
            // quảnLýToolStripMenuItem
            // 
            this.quảnLýToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.thôngTinCáNhânToolStripMenuItem,
            this.mônHọcToolStripMenuItem});
            this.quảnLýToolStripMenuItem.Name = "quảnLýToolStripMenuItem";
            this.quảnLýToolStripMenuItem.Size = new System.Drawing.Size(71, 20);
            this.quảnLýToolStripMenuItem.Text = "Tài khoản";
            // 
            // thôngTinCáNhânToolStripMenuItem
            // 
            this.thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
            this.thôngTinCáNhânToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.thôngTinCáNhânToolStripMenuItem.Text = "Thông tin cá nhân";
            this.thôngTinCáNhânToolStripMenuItem.Click += new System.EventHandler(this.thôngTinCáNhânToolStripMenuItem_Click);
            // 
            // mônHọcToolStripMenuItem
            // 
            this.mônHọcToolStripMenuItem.Name = "mônHọcToolStripMenuItem";
            this.mônHọcToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.mônHọcToolStripMenuItem.Text = "Thoát";
            this.mônHọcToolStripMenuItem.Click += new System.EventHandler(this.ThoátToolStripMenuItem_Click);
            // 
            // thoátToolStripMenuItem
            // 
            this.thoátToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mônHọcToolStripMenuItem1});
            this.thoátToolStripMenuItem.Name = "thoátToolStripMenuItem";
            this.thoátToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.thoátToolStripMenuItem.Text = "Quản lý";
            // 
            // mônHọcToolStripMenuItem1
            // 
            this.mônHọcToolStripMenuItem1.Name = "mônHọcToolStripMenuItem1";
            this.mônHọcToolStripMenuItem1.Size = new System.Drawing.Size(122, 22);
            this.mônHọcToolStripMenuItem1.Text = "Môn học";
            this.mônHọcToolStripMenuItem1.Click += new System.EventHandler(this.mônHọcToolStripMenuItem1_Click);
            // 
            // tìmKiếmToolStripMenuItem
            // 
            this.tìmKiếmToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem,
            this.danhSáchCácMônHọcToolStripMenuItem,
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem});
            this.tìmKiếmToolStripMenuItem.Name = "tìmKiếmToolStripMenuItem";
            this.tìmKiếmToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.tìmKiếmToolStripMenuItem.Text = "Tìm kiếm";
            // 
            // danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem
            // 
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Name = "danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem";
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Text = "Danh sách các chương trình đào tạo";
            this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem.Click += new System.EventHandler(this.danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem_Click);
            // 
            // danhSáchCácMônHọcToolStripMenuItem
            // 
            this.danhSáchCácMônHọcToolStripMenuItem.Name = "danhSáchCácMônHọcToolStripMenuItem";
            this.danhSáchCácMônHọcToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.danhSáchCácMônHọcToolStripMenuItem.Text = "Danh sách các môn học";
            this.danhSáchCácMônHọcToolStripMenuItem.Click += new System.EventHandler(this.danhSáchCácMônHọcToolStripMenuItem_Click);
            // 
            // kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem
            // 
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Name = "kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem";
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Size = new System.Drawing.Size(265, 22);
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Text = "Kết quả các môn học của Sinh viên";
            this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem.Click += new System.EventHandler(this.kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem_Click);
            // 
            // lậpBáoCáoToolStripMenuItem
            // 
            this.lậpBáoCáoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chiTiếtMônHọcToolStripMenuItem,
            this.danhSáchSinhViênToolStripMenuItem});
            this.lậpBáoCáoToolStripMenuItem.Name = "lậpBáoCáoToolStripMenuItem";
            this.lậpBáoCáoToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.lậpBáoCáoToolStripMenuItem.Text = "Lập báo cáo";
            // 
            // chiTiếtMônHọcToolStripMenuItem
            // 
            this.chiTiếtMônHọcToolStripMenuItem.Name = "chiTiếtMônHọcToolStripMenuItem";
            this.chiTiếtMônHọcToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.chiTiếtMônHọcToolStripMenuItem.Text = "Chi tiết môn học";
            this.chiTiếtMônHọcToolStripMenuItem.Click += new System.EventHandler(this.chiTiếtMônHọcToolStripMenuItem_Click);
            // 
            // danhSáchSinhViênToolStripMenuItem
            // 
            this.danhSáchSinhViênToolStripMenuItem.Name = "danhSáchSinhViênToolStripMenuItem";
            this.danhSáchSinhViênToolStripMenuItem.Size = new System.Drawing.Size(179, 22);
            this.danhSáchSinhViênToolStripMenuItem.Text = "Danh sách sinh viên";
            this.danhSáchSinhViênToolStripMenuItem.Click += new System.EventHandler(this.danhSáchSinhViênToolStripMenuItem_Click);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(0, 606);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(770, 51);
            this.textBox1.TabIndex = 12;
            this.textBox1.Text = "TRƯỜNG ĐẠI HỌC CẦN THƠ\r\nKHOA CÔNG NGHỆ THÔNG TIN VÀ TRUYỀN THÔNG\r\nLỚP LIÊN THÔNG " +
    "DC15V7K2\r\nNhóm 5 © 2017";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // frmGiaoVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(770, 657);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.mstgiaovien);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mstgiaovien;
            this.MaximizeBox = false;
            this.Name = "frmGiaoVien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PHẦN QUẢN LÝ DÀNH CHO GIÁO VIÊN";
            this.Load += new System.EventHandler(this.frmGiaoVien_Load);
            this.mstgiaovien.ResumeLayout(false);
            this.mstgiaovien.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mstgiaovien;
        private System.Windows.Forms.ToolStripMenuItem quảnLýToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lậpBáoCáoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chiTiếtMônHọcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem thoátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mônHọcToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tìmKiếmToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kếtQuảCácMônHọcCủaSinhViênToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchCácChươngTrìnhĐàoTạoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem danhSáchCácMônHọcToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
    }
}