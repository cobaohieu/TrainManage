﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingManagement.Entities
{
    class tblKetQua
    {
        int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        int _idsinhvien;

        public int Idsinhvien
        {
            get { return _idsinhvien; }
            set { _idsinhvien = value; }
        }
        int _idmonhoc;

        public int Idmonhoc
        {
            get { return _idmonhoc; }
            set { _idmonhoc = value; }
        }
        float _diemtrungbinh;

        public float Diemtrungbinh
        {
            get { return _diemtrungbinh; }
            set { _diemtrungbinh = value; }
        }
        float _diemthilan1;

        public float Diemthilan1
        {
            get { return _diemthilan1; }
            set { _diemthilan1 = value; }
        }
        float _diemthilan2;

        public float Diemthilan2
        {
            get { return _diemthilan2; }
            set { _diemthilan2 = value; }
        }
        float _diemtongket;

        public float Diemtongket
        {
            get { return _diemtongket; }
            set { _diemtongket = value; }
        }
        string _hanhkiem;

        public string Hanhkiem
        {
            get { return _hanhkiem; }
            set { _hanhkiem = value; }
        }
        string _ghichu;

        public string Ghichu
        {
            get { return _ghichu; }
            set { _ghichu = value; }
        }
    }
}
