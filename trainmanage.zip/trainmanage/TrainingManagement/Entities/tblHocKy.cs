﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TrainingManagement.Entities
{
    class tblHocKy
    {
        int _id;

        public int Id
        {
            get { return _id; }
            set { _id = value; }
        }
        string _mahocky;

        public string Mahocky
        {
            get { return _mahocky; }
            set { _mahocky = value; }
        }
        string _tenhocky;

        public string Tenhocky
        {
            get { return _tenhocky; }
            set { _tenhocky = value; }
        }
    }
}
